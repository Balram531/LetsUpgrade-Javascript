
let n = prompt("Enter the range");

nextPrime:
for (let i = 2; i <= n; i++) {

  for (let j = 2; j < i; j++) {
    if (i % j == 0) continue nextPrime; 
  }
  document.write("\n");
  document.write( i ); 
}