var Total_Sales=prompt("Enter the amount how much u sale ");
if(Total_Sales >20000)
{
	let Commission1=5000*2/100;
	console.log(Commission1);
	let Commission2=5000*5/100;
	console.log(Commission2);
	let Commission3=10000*7/100;
	console.log(Commission3);
	let Commission4=(Total_Sales-20000)*10/100;
	console.log(Commission4);
	let Total_Commission=Commission1+Commission2+Commission3+Commission4;
	console.log(Total_Commission);

}
else if(Total_Sales >10000&&Total_Sales<=20000)
{
	let Commission1=5000*2/100;
	console.log(Commission1);
	let Commission2=5000*5/100;
	console.log(Commission2);
	let Commission3=(Total_Sales- 10000)*7/100;
	console.log(Commission3);
	let Total_Commission=Commission1+Commission2+Commission3;
	console.log(Total_Commission);

}
else if(Total_Sales >5000&&Total_Sales<=10000)
{
	let Commission1=5000*2/100;
	console.log(Commission1);
	let Commission2= (Total_Sales-5000)*5/100;
	console.log(Commission2);
	let Total_Commission=Commission1+Commission2;
	console.log(Total_Commission);

}
else if(Total_Sales<=5000)
{
	let Commission1=5000*2/100;
	console.log(Commission1);
	let Total_Commission=Commission1;
	console.log(Total_Commission);

}
