function add(){
	var a,b,c;
	a=Number(document.getElementById('First_input').value);
	b=Number(document.getElementById('Second_input').value);
	c=a+b;
	document.getElementById('Final_output').value=c;
}

function sub(){
	var a,b,c;
	a=Number(document.getElementById('First_input').value);
	b=Number(document.getElementById('Second_input').value);
	c=a-b;
	document.getElementById('Final_output').value=c;
}

function mul(){
	var a,b,c;
	a=Number(document.getElementById('First_input').value);
	b=Number(document.getElementById('Second_input').value);
	c=a*b;
	document.getElementById('Final_output').value=c;
}

function div(){
	var a,b,c;
	a=Number(document.getElementById('First_input').value);
	b=Number(document.getElementById('Second_input').value);
	c=a/b;
	document.getElementById('Final_output').value=c;
}

function Percentage(){
	var a,b,c;
	a=Number(document.getElementById('First_input').value);
	b=Number(document.getElementById('Second_input').value);
	c=(a/b)*100;
	document.getElementById('Final_output').value=c;
}
function square_root(){
	var a,c;
	a=Number(document.getElementById('First_input').value);
	c=Math.sqrt(a);
	document.getElementById('Final_output').value=c;
}