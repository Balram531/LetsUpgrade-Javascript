shoppingList=["Grains","oils"];
shoppingBucket=[];
shoppingBucket.push(shoppingList);
shoppingBucket.push("milk");