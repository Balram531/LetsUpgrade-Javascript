ask();
function ask(){
	var answer=prompt("Enter the number");
	if(answer>=100){
		alert("Correct");
		return
	}
	alert("Wrong answer");
	ask();
}